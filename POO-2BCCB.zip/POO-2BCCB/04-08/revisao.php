<?php
#c:\xampp\htdocs\POO-2BCCB\04-08\revisao.php

#and &&
#or ||
#not !
#diferença !=

$n1 = 10;
$n2 = 20;

$media = ($n1 + $n2) / 2;

#number_format() passa 3 parâmetros, a variável, as casas decimais e oq vai substituir
echo "Sua média é " . number_format($media, 2, ",");
echo "\n";

#if elseif e else
if ($media >= 7) {
    echo "Aprovado";
} elseif ($media >= 4) {
    echo "Exame";
} else {
    echo "Reprovado";
}

echo "\n\n--\n\n";

#Arrays e foreach
$nomes = ["João", "Maria", "Little Carlos", "Dalva"];

#foreach() é o for do python no php, 1 parametro é a var e o 2 parametro é a var de contexto
foreach($nomes as $nome){
    echo "Olá ". $nome . "!\n";
}

echo "\n\n--\n\n";

#while
$contador = 6;

while($contador > 0){
    $par = $contador % 2 == 0;                             #true   #false
    $msg = "O Número " . $contador . " é Par? " . ($par ? "Par" : "Impar") . "\n";
    
    echo $msg;

    $contador --;
}

?>